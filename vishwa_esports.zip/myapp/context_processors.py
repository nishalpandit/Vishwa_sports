from .models import UserProfile

def user_profile_context(request):
    """
    Exposes user metadata directly to all server-rendered Django HTML templates.
    Eliminates the need for JavaScript-based profile hydration or DOM manipulation.
    """
    if hasattr(request, 'user') and request.user.is_authenticated:
        name = request.user.first_name or request.user.username
        initial = name[0].upper() if name else "U"
        role = "Staff"
        try:
            role = request.user.userprofile.role
        except Exception:
            pass
        return {
            'current_user_name': name,
            'current_user_initial': initial,
            'current_user_role': role,
        }
    return {
        'current_user_name': 'Guest',
        'current_user_initial': 'G',
        'current_user_role': 'Guest',
    }
