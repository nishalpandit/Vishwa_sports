// ─── Data ───
const orders = window.ordersData || [];


// Canvas state



let currentCanvasOrder = null;
let mockupGenerated = false;
let designMode = "ai"; // "ai" = fields optional, AI fills gaps | "manual" = all fields required

const AUTO_FABRICS = ["Polyester", "Cotton Blend", "Mesh"];
const AUTO_COLORS = ["#FFFFFF", "#2B2620", "#A33B3B", "#2F6F63", "#6B8E4E", "#C1652C", "#6B4A6B", "#C1652C"];
function pickRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function switchDesignMode(mode) {
  designMode = mode;
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));

  const tags = ["tagFabric", "tagPrimaryColor", "tagSecondaryColor"];
  tags.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = mode === "manual" ? "Required" : "Optional";
    el.classList.toggle("required", mode === "manual");
    el.classList.toggle("optional", mode === "ai");
  });

  const hintEl = document.getElementById("modeHint");
  if (hintEl) {
    hintEl.textContent = mode === "manual"
      ? "Manual mode: set fabric, colors and pattern yourself — the AI will render your exact spec."
      : "In AI mode, colors, fabric & pattern are optional — leave on \"Auto\" and the AI will choose. Switch to Manual to set every field yourself.";
  }

  document.querySelectorAll('.fabric-cards .fabric-card[data-fabric="auto"]').forEach(el => el.style.display = mode === "manual" ? "none" : "");
  document.querySelectorAll('.color-picker .auto-swatch').forEach(el => el.style.display = mode === "manual" ? "none" : "");

  // If switching to manual and an "auto" is currently selected, clear it so the user must pick
  if (mode === "manual") {
    const fabricSel = document.querySelector('.fabric-card.selected');
    if (fabricSel && fabricSel.dataset.fabric === "auto") fabricSel.classList.remove("selected");
    document.querySelectorAll('.color-picker').forEach(p => {
      const sel = p.querySelector('.color-option.selected');
      if (sel && sel.dataset.color === "auto") sel.classList.remove("selected");
    });
  } else {
    // Switching back to AI: default back to Auto for anything unset
    if (!document.querySelector('.fabric-card.selected')) {
      const el = document.querySelector('.fabric-card[data-fabric="auto"]');
      if (el) el.classList.add("selected");
    }
    document.querySelectorAll('.color-picker').forEach(p => {
      if (!p.querySelector('.color-option.selected')) {
        const el = p.querySelector('.auto-swatch');
        if (el) el.classList.add("selected");
      }
    });
  }
  try { calcSuggestedPrice(); } catch (e) { }
}

const now = new Date("2026-07-22T12:00:00Z");

// ─── Helpers ───
function getCSRFToken() {
  const name = 'csrftoken';
  const cookies = document.cookie.split(';');
  for (let c of cookies) {
    c = c.trim();
    if (c.startsWith(name + '=')) return c.substring(name.length + 1);
  }
  return '';
}
function formatCurrency(v) { return "₹" + Math.round(v).toLocaleString("en-IN"); }
function getStatusLabel(s) {
  const map = { new: "New", design_in_progress: "In Design", awaiting_approval: "Awaiting Approval", declined: "Declined", qty_pending: "Qty Pending", in_production: "In Production", qc: "Quality Check", ready_for_payment: "Ready for Payment", paid: "Paid", shipped: "Shipped" };
  return map[s] || s;
}
function getStatusBadge(s) {
  const cls = { new: "badge-blue", design_in_progress: "badge-orange", awaiting_approval: "badge-purple", declined: "badge-red", qty_pending: "badge-gray", in_production: "badge-blue", qc: "badge-orange", ready_for_payment: "badge-green", paid: "badge-green", shipped: "badge-green" };
  return `<span class="badge ${cls[s] || 'badge-gray'}">${getStatusLabel(s)}</span>`;
}
function timeAgo(dateStr) {
  const diff = now - new Date(dateStr);
  const hrs = Math.floor(diff / 3600000);
  if (hrs < 24) return hrs + "h ago";
  return Math.floor(hrs / 24) + "d ago";
}

// ─── Section Navigation ───
function showSection(section) {
  document.querySelectorAll('.page-section').forEach(el => el.classList.remove('active'));
  document.getElementById('section-' + section).classList.add('active');
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(el => el.classList.remove('active'));
  event.currentTarget.classList.add('active');

  if (section === 'charts') renderCharts();
  if (section === 'canvas') populateCanvasOrderSelect();
}

// ─── KPIs ───
function renderKPIs() {
  if (!document.getElementById("kpiRow")) return;
  const total = orders.length;
  const createdToday = 0; // Placeholder
  const pendingApproval = orders.filter(o => o.status === "awaiting_approval").length;
  const changesRequested = 0; // Placeholder
  const approved = orders.filter(o => ["approved", "qty_pending", "in_production", "qc", "ready_for_payment", "paid", "shipped"].includes(o.status)).length;
  const mockupsPending = orders.filter(o => o.status === "design_in_progress").length;
  const cutoutsPending = 0; // Placeholder
  const sentToProduction = 0; // Placeholder
  const inProduction = orders.filter(o => o.status === "in_production").length;
  const completed = orders.filter(o => ["shipped"].includes(o.status)).length;

  document.getElementById("kpiRow").innerHTML = `
    <div class="kpi-card"><div class="info"><div class="label">Total Designs</div><div class="value">${total}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Created Today</div><div class="value">${createdToday}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Pending Approval</div><div class="value">${pendingApproval}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Changes Requested</div><div class="value">${changesRequested}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Approved Designs</div><div class="value">${approved}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Mockups Pending</div><div class="value">${mockupsPending}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Cutouts Pending</div><div class="value">${cutoutsPending}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Sent to Prod</div><div class="value">${sentToProduction}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">In Production</div><div class="value">${inProduction}</div></div></div>
    <div class="kpi-card"><div class="info"><div class="label">Completed</div><div class="value">${completed}</div></div></div>
  `;
}

// ─── Dashboard Queue ───
function renderDashboardQueue() {
  if (!document.getElementById("dashboardQueueBody")) return;
  const designerStatuses = ["new", "design_in_progress", "awaiting_approval"];
  const filtered = orders.filter(o => designerStatuses.includes(o.status)).slice(0, 5);
  const tbody = document.getElementById("dashboardQueueBody");
  tbody.innerHTML = filtered.map(o => `
    <tr onclick="openOrderInCanvas('${o.id}')">
      <td><strong>${o.id}</strong></td>
      <td>${o.clientName}</td>
      <td>${o.jerseyType}</td>
      <td>${getStatusBadge(o.status)}</td>
      <td><button class="btn btn-sm btn-primary" onclick="event.stopPropagation();openOrderInCanvas('${o.id}')">Design</button></td>
    </tr>
  `).join("");
}

// ─── Queue Table ───
let searchTerm = "";
function filterQueue() {
  searchTerm = document.getElementById("globalSearch")?.value?.toLowerCase() || '';
  renderQueue();
}
function renderQueue() {
  if (!document.getElementById("queueTableBody")) return;
  const designerStatuses = ["new", "design_in_progress", "awaiting_approval"];
  let filtered = orders.filter(o => designerStatuses.includes(o.status));
  if (searchTerm) {
    filtered = filtered.filter(o => o.id.toLowerCase().includes(searchTerm) || o.clientName.toLowerCase().includes(searchTerm));
  }
  filtered.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

  document.getElementById("queueCount").textContent = filtered.length + " orders";
  const tbody = document.getElementById("queueTableBody");
  tbody.innerHTML = filtered.map(o => `
    <tr onclick="openOrderInCanvas('${o.id}')">
      <td><strong>${o.id}</strong></td>
      <td>${o.clientName}</td>
      <td>${o.jerseyType}</td>
      <td>${o.prelimSize}</td>
      <td>${getStatusBadge(o.status)}</td>
      <td style="color:#7A7267;font-size:12px;">${timeAgo(o.createdAt)}</td>
      <td><button class="btn btn-sm btn-primary" onclick="event.stopPropagation();openOrderInCanvas('${o.id}')">Design</button></td>
    </tr>
  `).join("");
}

// ─── History ───
function renderHistory() {
  if (!document.getElementById("historyTableBody")) return;
  const historyStatuses = ["awaiting_approval", "qty_pending", "in_production", "qc", "ready_for_payment", "paid", "shipped", "declined"];
  const filtered = orders.filter(o => historyStatuses.includes(o.status));
  document.getElementById("historyCount").textContent = filtered.length + " designs";
  const tbody = document.getElementById("historyTableBody");
  tbody.innerHTML = filtered.map(o => {
    let outcome = '';
    if (o.status === "declined") outcome = '<span class="badge badge-red">Declined</span>';
    else if (o.status === "awaiting_approval") outcome = '<span class="badge badge-purple" style="background:#f3e8ff;color:#7e22ce;">Pending Approval</span>';
    else outcome = '<span class="badge badge-green">Approved</span>';
    return `
    <tr>
      <td><strong>${o.id}</strong></td>
      <td>${o.clientName}</td>
      <td>${o.jerseyType}</td>
      <td>${o.unitPrice > 0 ? formatCurrency(o.unitPrice) : '—'}</td>
      <td>${o.quantity || '—'}</td>
      <td>${o.totalCost > 0 ? formatCurrency(o.totalCost) : '—'}</td>
      <td>${getStatusBadge(o.status)}</td>
      <td>${outcome}</td>
    </tr>`;
  }).join("");
}

// ─── Design Canvas ───
function populateCanvasOrderSelect() {
  const select = document.getElementById("canvasOrderSelect");
  if (!select) return;
  const currentVal = select.value;
  select.innerHTML = '<option value="">— Select an order or catalog item —</option>' + orders.map(o =>
    `<option value="${o.id}">${o.id} — ${o.clientName} (${o.jerseyType})</option>`
  ).join("");
  if (currentVal) select.value = currentVal;
}

function openOrderInCanvas(id) {
  if (!document.getElementById("canvasOrderSelect")) {
    window.location.href = "/designer_dashboard/canvas.html?order=" + id;
    return;
  }
  showSection('canvas');
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.sidebar-nav .nav-item')[2].classList.add('active');
  populateCanvasOrderSelect();
  document.getElementById("canvasOrderSelect").value = id;
  loadOrderToCanvas();
}

function loadOrderToCanvas() {
  const id = document.getElementById("canvasOrderSelect").value;
  if (!id) {
    document.getElementById("canvasWorkspace").style.display = "none";
    document.getElementById("canvasEmpty").style.display = "block";
    currentCanvasOrder = null;
    return;
  }

  const o = orders.find(x => x.id === id);
  if (!o) return;

  currentCanvasOrder = o;
  mockupGenerated = false;

  document.getElementById("canvasWorkspace").style.display = "block";
  document.getElementById("canvasEmpty").style.display = "none";

  // Pre-fill from order
  document.getElementById("jerseyType").value = o.jerseyType;

  const nameParts = o.designAssets.nameNumber.split(' / ');
  document.getElementById("playerName").value = nameParts[0] || '';
  document.getElementById("jerseyNumber").value = nameParts[1] || '';

  if (o.designAssets && o.designAssets.logoUrl) {
    const fn = o.designAssets.logoUrl.split('/').pop();
    document.getElementById("logoFileName").innerHTML = "✓ " + fn + `<br><img src="${o.designAssets.logoUrl}" style="max-height:40px;margin-top:6px;border-radius:4px;">`;
    document.getElementById("logoFileName").style.display = "block";
  } else {
    document.getElementById("logoFileName").style.display = "none";
  }

  if (o.designPreviewUrl) {
    const fn = o.designPreviewUrl.split('/').pop();
    document.getElementById("designFileName").innerHTML = `✓ Attached Design:<br><img src="${o.designPreviewUrl}" style="max-width:100%;max-height:100px;margin-top:6px;border-radius:4px;">`;
    document.getElementById("designFileName").style.display = "block";
    document.getElementById("noDesignText").style.display = "none";
  } else {
    document.getElementById("designFileName").style.display = "none";
    document.getElementById("noDesignText").style.display = "block";
  }

  // Reset preview
  resetPreview();

  // If the order already has an AI-generated mockup saved, we can show it
  if (o.mockupUrl) {
    const previewDiv = document.getElementById("previewImage");
    previewDiv.innerHTML = `<div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:10px;"><img id="mockupImage" src="${o.mockupUrl}" alt="Jersey Mockup" style="max-width:100%;max-height:100%;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.2);object-fit:contain;"></div>`;
    previewDiv.style.display = "flex";
    document.getElementById("jerseyPreview").classList.add("has-design");
    document.getElementById("sendToClientBtn").disabled = false;
    mockupGenerated = true;
  }

  calcSuggestedPrice();

  // Mark as in progress if new
  if (o.status === "new") {
    o.status = "design_in_progress";
    o.history.push({ step: "Design Started", at: now.toISOString() });
    showToast("Started designing " + o.id);
    renderAll();
  }
}

function resetPreview() {
  document.getElementById("jerseyPreview").classList.remove("has-design");
  document.getElementById("previewImage").style.display = "none";
  document.getElementById("mockupResult").classList.remove("show");
  document.getElementById("sendToClientBtn").disabled = true;
  mockupGenerated = false;
}

function resetCanvas() {
  document.getElementById("canvasOrderSelect").value = "";
  loadOrderToCanvas();
  showToast("Canvas reset");
}

// Size selector
document.querySelectorAll('.size-option').forEach(el => {
  el.addEventListener('click', function () {
    document.querySelectorAll('.size-option').forEach(s => s.classList.remove('selected'));
    this.classList.add('selected');
  });
});

// Fabric selector
document.querySelectorAll('.fabric-card').forEach(el => {
  el.addEventListener('click', function () {
    document.querySelectorAll('.fabric-card').forEach(f => f.classList.remove('selected'));
    this.classList.add('selected');
    calcSuggestedPrice();
  });
});

// Color pickers
document.querySelectorAll('.color-picker').forEach(picker => {
  picker.querySelectorAll('.color-option').forEach(el => {
    el.addEventListener('click', function () {
      picker.querySelectorAll('.color-option').forEach(c => c.classList.remove('selected'));
      this.classList.add('selected');
    });
  });
});

// Price calculator
function calcSuggestedPrice() {
  const base = parseFloat(document.getElementById("calcBase").value) || 0;
  const complex = parseFloat(document.getElementById("calcComplex").value) || 1;
  const margin = parseFloat(document.getElementById("calcMargin").value) || 0;
  const fabric = document.querySelector('.fabric-card.selected')?.dataset.fabric || 'auto';
  const fabricMult = fabric === 'Mesh' ? 1.1 : fabric === 'Cotton Blend' ? 1.15 : 1; // 'auto'/'Polyester' both default to 1x
  const result = base * complex * fabricMult * (1 + margin / 100);
  document.getElementById("suggestedPrice").value = formatCurrency(result);
}
document.getElementById("calcBase").addEventListener("input", calcSuggestedPrice);
document.getElementById("calcComplex").addEventListener("input", calcSuggestedPrice);
document.getElementById("calcMargin").addEventListener("input", calcSuggestedPrice);

function simulateLogoUpload() {
  const fn = "logo_" + (currentCanvasOrder?.clientName.replace(/\s/g, '_').toLowerCase() || 'team') + ".png";
  document.getElementById("logoFileName").textContent = "✓ " + fn;
  document.getElementById("logoFileName").style.display = "block";
  showToast("Logo uploaded: " + fn);
}

// Generate AI Mockup
async function generateAIMockup() {
  if (!currentCanvasOrder) {
    showToast("Please select an order first", true);
    return;
  }

  // In Manual mode, every design field is required — validate before generating
  if (designMode === "manual") {
    const missing = [];
    if (!document.querySelector('.fabric-card.selected')) missing.push("Fabric Type");
    if (!document.querySelector('.color-picker:first-of-type .color-option.selected')) missing.push("Primary Color");
    if (!document.querySelector('#secondaryColorPicker .color-option.selected')) missing.push("Secondary Color");
    if (missing.length) {
      showToast("Manual mode requires: " + missing.join(", "), true);
      return;
    }
  }

  const overlay = document.getElementById("generatingOverlay");
  overlay.classList.add("show");

  // Resolve field values — in AI mode, anything left on "Auto" gets a sensible AI-picked value
  let primaryColor = document.querySelector('.color-picker:first-of-type .color-option.selected')?.dataset.color || 'auto';
  let secondaryColor = document.querySelector('#secondaryColorPicker .color-option.selected')?.dataset.color || 'auto';
  let fabric = document.querySelector('.fabric-card.selected')?.dataset.fabric || 'auto';
  let aiChose = [];

  if (primaryColor === 'auto') { primaryColor = pickRandom(AUTO_COLORS); aiChose.push('primary color'); }
  if (secondaryColor === 'auto') { secondaryColor = pickRandom(AUTO_COLORS.filter(c => c !== primaryColor)); aiChose.push('secondary color'); }
  if (fabric === 'auto') { fabric = pickRandom(AUTO_FABRICS); aiChose.push('fabric'); }

  const name = document.getElementById("playerName").value || 'PLAYER';
  const number = document.getElementById("jerseyNumber").value || '10';
  const type = document.getElementById("jerseyType").value;

  const prompt = `A highly detailed, realistic front and back 3D mockup of a ${type} sports jersey made of ${fabric} fabric. The primary color is ${primaryColor} and the secondary color is ${secondaryColor}. The player name "${name}" and the number "${number}" are clearly printed. Professional product photography, clean background, 8k resolution, cinematic lighting.`;

  try {
    const response = await fetch('/api/generate-image/', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'X-CSRFToken': getCSRFToken() 
      },
      body: JSON.stringify({ prompt })
    });
    
    const data = await response.json();
    overlay.classList.remove("show");
    
    if (data.success) {
      // Show generated mockup
      const preview = document.getElementById("jerseyPreview");
      preview.classList.add("has-design");

      document.getElementById("previewImage").innerHTML = `
        <div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:10px;">
          <img id="mockupImage" src="${data.image_url}" alt="Jersey Mockup" style="max-width:100%;max-height:100%;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.2);object-fit:contain;">
          <div style="margin-top:16px;font-size:12px;color:#7A7267;">
            ${type} · ${fabric}
          </div>
        </div>
      `;
      document.getElementById("previewImage").style.display = "flex";

      const resultNote = document.querySelector("#mockupResult p");
      resultNote.textContent = aiChose.length
        ? `The mockup has been created using Flux AI. The AI auto-selected: ${aiChose.join(', ')}. Review it and send to the client for approval.`
        : "The mockup has been created using Flux AI based on your exact configuration. Review it and send to the client for approval.";

      document.getElementById("mockupResult").classList.add("show");
      document.getElementById("sendToClientBtn").disabled = false;
      mockupGenerated = true;

      // Save mockup reference
      currentCanvasOrder.designPreviewUrl = data.image_url;

      showToast(aiChose.length ? `Flux AI Mockup generated — auto-picked ${aiChose.join(', ')}` : "Flux AI Mockup generated successfully!");
    } else {
      showToast(data.error || 'Failed to generate AI image', true);
    }
  } catch(err) {
    console.error(err);
    overlay.classList.remove("show");
    showToast('Network error while generating image', true);
  }
}

// Send to Client
async function sendToClient() {
  if (!currentCanvasOrder || !mockupGenerated) {
    showToast("Please generate a mockup first", true);
    return;
  }

  const price = parseFloat(document.getElementById("suggestedPrice").value.replace(/[₹,]/g, ''));
  if (price <= 0) {
    showToast("Please set a valid price", true);
    return;
  }

  const btn = document.getElementById("sendToClientBtn");
  btn.disabled = true;
  const originalText = btn.innerText;
  btn.innerText = "Sending...";

  try {
    const previewEl = document.getElementById("previewImage");
    const canvas = await html2canvas(previewEl, { backgroundColor: null });
    
    canvas.toBlob(async (blob) => {
      const formData = new FormData();
      formData.append("mockup", blob, `mockup_${currentCanvasOrder.id}.png`);
      formData.append("order_status", "awaiting_approval");
      formData.append("unit_price", price);
      formData.append("history_step", "Design Sent to Client for Approval");

      try {
        const response = await fetch(`/api/products/${currentCanvasOrder.raw_id}/update/`, {
          method: "POST",
          body: formData
        });

        const data = await response.json();
        if (data.success) {
          currentCanvasOrder.unitPrice = price;
          currentCanvasOrder.status = "awaiting_approval";
          currentCanvasOrder.history.push({ step: "Design Sent to Client for Approval", at: new Date().toISOString() });
          currentCanvasOrder.mockupUrl = data.product.mockup || currentCanvasOrder.mockupUrl;

          showToast("Mockup sent to " + currentCanvasOrder.clientName + " for approval at " + formatCurrency(price));

          // Reset canvas
          document.getElementById("canvasOrderSelect").value = "";
          loadOrderToCanvas();
          populateCanvasOrderSelect();
          renderAll();
        } else {
          showToast("Failed to send: " + data.error, true);
        }
      } catch (err) {
        showToast("Network error while sending.", true);
      } finally {
        btn.disabled = false;
        btn.innerText = originalText;
      }
    }, "image/png");
  } catch (err) {
    showToast("Error capturing design: " + err, true);
    btn.disabled = false;
    btn.innerText = originalText;
  }
}

// ─── Charts ───
let doughnutChart, barChart, lineChart, typeChart;

function renderCharts() {
  // Status Doughnut
  const statusCounts = { new: 0, design_in_progress: 0, awaiting_approval: 0, declined: 0 };
  orders.forEach(o => { if (statusCounts.hasOwnProperty(o.status)) statusCounts[o.status]++; });

  const ctx1 = document.getElementById("statusDoughnut");
  if (ctx1) {
    if (doughnutChart) doughnutChart.destroy();
    doughnutChart = new Chart(ctx1, {
      type: 'doughnut',
      data: {
        labels: ["New", "In Design", "Awaiting Approval", "Declined"],
        datasets: [{ data: Object.values(statusCounts), backgroundColor: ["#2F6F63", "#C1652C", "#6B4A6B", "#A33B3B"], borderWidth: 0 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 11 } } } }, cutout: '65%' }
    });
  }

  // Designs per day
  const ctx2 = document.getElementById("designsBarChart");
  if (ctx2) {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const designsPerDay = [3, 5, 2, 4, 6, 1, 3];
    if (barChart) barChart.destroy();
    barChart = new Chart(ctx2, {
      type: 'bar',
      data: {
        labels: days,
        datasets: [{ label: 'Designs Created', data: designsPerDay, backgroundColor: '#2F6F63', borderRadius: 8, barThickness: 32 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } }, x: { grid: { display: false } } } }
    });
  }

  // Approval rate trend
  const ctx3 = document.getElementById("approvalLineChart");
  if (ctx3) {
    const weeks = ["W1", "W2", "W3", "W4", "W5", "W6"];
    const rates = [85, 78, 92, 88, 75, 83];
    if (lineChart) lineChart.destroy();
    lineChart = new Chart(ctx3, {
      type: 'line',
      data: {
        labels: weeks,
        datasets: [{ label: 'Approval Rate %', data: rates, borderColor: '#6B8E4E', backgroundColor: 'rgba(107,142,78,0.1)', fill: true, tension: 0.4, pointBackgroundColor: '#6B8E4E', pointRadius: 5, pointHoverRadius: 7 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { min: 50, max: 100, ticks: { callback: v => v + '%' } }, x: { grid: { display: false } } } }
    });
  }

  // Production Volume
  const ctx4 = document.getElementById("productionVolumeChart");
  if (ctx4) {
    if (typeChart) typeChart.destroy();
    typeChart = new Chart(ctx4, {
      type: 'bar',
      data: {
        labels: ['Total Jerseys', 'In Production', 'Completed'],
        datasets: [{ label: 'Volume', data: [150, 45, 105], backgroundColor: ['#2F6F63', '#C1652C', '#6B8E4E'], borderRadius: 8, barThickness: 40 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true }, x: { grid: { display: false } } } }
    });
  }

  // Designer Performance KPIs
  const performanceKPIs = document.getElementById("designerPerformanceKPIs");
  if (performanceKPIs) {
    performanceKPIs.innerHTML = `
      <div class="kpi-card"><div class="info"><div class="label">Designs Created</div><div class="value">24</div></div></div>
      <div class="kpi-card"><div class="info"><div class="label">Designs Approved</div><div class="value">18</div></div></div>
      <div class="kpi-card"><div class="info"><div class="label">Mockups Generated</div><div class="value">32</div></div></div>
      <div class="kpi-card"><div class="info"><div class="label">Cutouts Generated</div><div class="value">12</div></div></div>
      <div class="kpi-card"><div class="info"><div class="label">Avg Approval Time</div><div class="value">1.5 days</div></div></div>
      <div class="kpi-card"><div class="info"><div class="label">Avg Revisions</div><div class="value">1.2</div></div></div>
    `;
  }
}

// ─── Toast ───
function showToast(msg, isError) {
  const container = document.getElementById("toastContainer");
  const t = document.createElement("div");
  t.className = "toast" + (isError ? " error" : "");
  t.innerHTML = `<span class="toast-msg">${msg}</span><button class="toast-close" onclick="this.parentElement.remove()">&times;</button>`;
  container.appendChild(t);
  setTimeout(() => t.remove(), 4000);
}

// ─── Render All ───
function renderAll() {
  try { renderKPIs(); } catch (e) { }
  try { renderDashboardQueue(); } catch (e) { }
  try { renderQueue(); } catch (e) { }
  try { renderHistory(); } catch (e) { }
  try { renderCharts(); } catch (e) { }
  try { populateCanvasOrderSelect(); } catch (e) { }
}

document.addEventListener("DOMContentLoaded", () => {
  renderAll();
  try { switchDesignMode("ai"); } catch (e) { }

  // Check if we navigated directly to canvas with an order ID in URL
  try {
    const params = new URLSearchParams(window.location.search);
    const orderParam = params.get("order");
    if (orderParam && document.getElementById("canvasOrderSelect")) {
      populateCanvasOrderSelect();
      document.getElementById("canvasOrderSelect").value = orderParam;
      loadOrderToCanvas();
    }
  } catch (e) { }
});
